const sinon = require('sinon');
const expect = require("chai").expect;

describe('',  ()=> {
	let sandbox;
	beforeEach(()=> {
		sandbox = sinon.createSandbox();
	})
	afterEach(() => {
		sandbox.restore();
		sinon.restore();
	});
	describe('', ()=> {
		it('Should run happy path', ()=> {
		//	console.log('res: ', res);
		})
		it('Should ', ()=> {

		});
	})
	describe('runtime error', ()=>{
		it('Should ', ()=> {

		});
		it('Should ', ()=> {

		});
	});
});